from flask import Flask, render_template, request, redirect, session
import mysql.connector

app = Flask(__name__)
app.secret_key = "banksecret"

# MySQL connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Balajanani2406",
    database="bank"
)

cursor = db.cursor()

# ---------------- HOME PAGE ----------------

@app.route("/")
def index():
    return render_template("user/index.html")


# ---------------- REGISTER ----------------

@app.route("/register", methods=["GET","POST"])
def register():
    
    if request.method == "POST":
        
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]

        query = "INSERT INTO users(name,email,password) VALUES(%s,%s,%s)"
        values = (name,email,password)

        cursor.execute(query,values)
        db.commit()

        return redirect("/login")

    return render_template("user/register.html")


# ---------------- LOGIN ----------------

@app.route("/login", methods=["GET","POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        query = "SELECT * FROM users WHERE email=%s AND password=%s"
        values = (email,password)

        cursor.execute(query,values)
        user = cursor.fetchone()

        if user:
            session["user_id"] = user[0]
            session["user_name"] = user[1]
            return redirect("/dashboard")

    return render_template("user/login.html")


# ---------------- DASHBOARD ----------------

@app.route("/dashboard")
def dashboard():

    if "user_id" in session:
        return render_template("user/dashboard.html",name=session["user_name"])

    return redirect("/login")


# ---------------- LOGOUT ----------------

@app.route("/logout")
def logout():

    session.clear()
    return redirect("/")
@app.route("/account_details")
def account_details():

    if "user_id" not in session:
        return redirect("/login")

    user_id = session["user_id"]

    query = "SELECT name,email,balance FROM users WHERE id=%s"
    cursor.execute(query,(user_id,))
    user = cursor.fetchone()

    return render_template("user/account_details.html",user=user)

#deposit
@app.route("/deposit", methods=["GET","POST"])
def deposit():

    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":

        amount = request.form["amount"]
        user_id = session["user_id"]

        query = "UPDATE users SET balance = balance + %s WHERE id=%s"
        cursor.execute(query,(amount,user_id))
        db.commit()

        return redirect("/dashboard")

    return render_template("user/deposit.html")
#apply loan

@app.route("/apply_loan", methods=["GET","POST"])
def apply_loan():

    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":

        amount = request.form["amount"]
        user_id = session["user_id"]

        query = "INSERT INTO loans(user_id,amount) VALUES(%s,%s)"
        cursor.execute(query,(user_id,amount))
        db.commit()

        return redirect("/loan_status")

    return render_template("user/apply_loan.html")

#loan status

@app.route("/loan_status")
def loan_status():

    if "user_id" not in session:
        return redirect("/login")

    user_id = session["user_id"]

    query = "SELECT amount,status FROM loans WHERE user_id=%s"
    cursor.execute(query,(user_id,))
    loans = cursor.fetchall()

    return render_template("user/loan_status.html",loans=loans)

#money transert // transaction

@app.route("/transfer", methods=["GET","POST"])
def transfer():

    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":

        receiver_email = request.form["email"]
        amount = float(request.form["amount"])
        sender_id = session["user_id"]

        # Check sender balance
        cursor.execute("SELECT balance FROM users WHERE id=%s", (sender_id,))
        balance = cursor.fetchone()[0]

        if balance < amount:
            return "Insufficient Balance"

        # Find receiver
        cursor.execute("SELECT id FROM users WHERE email=%s", (receiver_email,))
        receiver = cursor.fetchone()

        if receiver is None:
            return "Receiver not found"

        receiver_id = receiver[0]

        # Deduct sender balance
        cursor.execute(
            "UPDATE users SET balance = balance - %s WHERE id=%s",
            (amount, sender_id)
        )

        # Add receiver balance
        cursor.execute(
            "UPDATE users SET balance = balance + %s WHERE id=%s",
            (amount, receiver_id)
        )

        # Record transaction
        cursor.execute(
            "INSERT INTO transactions(sender_id,receiver_id,amount,type) VALUES(%s,%s,%s,%s)",
            (sender_id, receiver_id, amount, "Transfer")
        )

        db.commit()

        return redirect("/transactions")

    return render_template("user/transfer.html")

    return render_template("user/transfer.html")
#history for transaction
@app.route("/transactions")
def transactions():

    if "user_id" not in session:
        return redirect("/login")

    user_id = session["user_id"]

    query = """
    SELECT sender_id,receiver_id,amount,type,date
    FROM transactions
    WHERE sender_id=%s OR receiver_id=%s
    ORDER BY date DESC
    """

    cursor.execute(query,(user_id,user_id))
    data = cursor.fetchall()

    return render_template("user/transaction.html", data=data)
#withdraw.html
@app.route("/withdraw", methods=["GET","POST"])
def withdraw():

    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":

        amount = float(request.form["amount"])
        user_id = session["user_id"]

        # Check balance
        cursor.execute("SELECT balance FROM users WHERE id=%s", (user_id,))
        balance = cursor.fetchone()[0]

        if balance < amount:
            return "Insufficient Balance"

        # Deduct balance
        cursor.execute(
            "UPDATE users SET balance = balance - %s WHERE id=%s",
            (amount, user_id)
        )

        # Save transaction
        cursor.execute(
            "INSERT INTO transactions(sender_id,receiver_id,amount,type) VALUES(%s,%s,%s,%s)",
            (user_id, user_id, amount, "Withdraw")
        )

        db.commit()

        return redirect("/transactions")

    return render_template("user/withdraw.html")

#=====admin===========
#admin login
@app.route("/admin", methods=["GET","POST"])
def admin_login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        # Static admin credentials
        if username == "admin" and password == "admin123":
            session["admin"] = "admin"
            return redirect("/admin_dashboard")
        else:
            return "Invalid Admin Login"

    return render_template("admin/admin_login.html")
#admib dashboard
@app.route("/admin_dashboard")
def admin_dashboard():

    if "admin" not in session:
        return redirect("/admin")

    return render_template("admin/admin_dashboard.html")

#admin add user
@app.route("/add_user", methods=["GET","POST"])
def add_user():

    if "admin" not in session:
        return redirect("/admin")

    if request.method == "POST":

        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        balance = request.form["balance"]

        query = "INSERT INTO users(name,email,password,balance) VALUES(%s,%s,%s,%s)"
        cursor.execute(query,(name,email,password,balance))
        db.commit()

        return redirect("/view_users")

    return render_template("admin/add_user.html")
#admin view users
@app.route("/view_users")
def view_users():

    if "admin" not in session:
        return redirect("/admin")

    cursor.execute("SELECT id,name,email,balance FROM users")
    users = cursor.fetchall()

    return render_template("admin/view_users.html",users=users)

#adin logout
@app.route("/admin_logout")
def admin_logout():

    session.pop("admin", None)
    return redirect("/admin")

#bank balanace
@app.route("/bank_balance")
def bank_balance():

    if "admin" not in session:
        return redirect("/admin")

    cursor.execute("SELECT SUM(balance) FROM users")
    total = cursor.fetchone()

    return render_template("admin/bank_balance.html", total=total[0])

#manage loans
@app.route("/manage_loans")
def manage_loans():

    if "admin" not in session:
        return redirect("/admin")

    cursor.execute("""
    SELECT loans.id, users.name, loans.amount, loans.status
    FROM loans
    JOIN users ON loans.user_id = users.id
    """)

    loans = cursor.fetchall()

    return render_template("admin/manage_loans.html", loans=loans)

#approve loans
@app.route("/approve_loan/<int:loan_id>")
def approve_loan(loan_id):

    if "admin" not in session:
        return redirect("/admin")

    cursor.execute("UPDATE loans SET status='Approved' WHERE id=%s",(loan_id,))
    db.commit()

    return redirect("/manage_loans")
#reject loans
@app.route("/reject_loan/<int:loan_id>")
def reject_loan(loan_id):

    if "admin" not in session:
        return redirect("/admin")

    cursor.execute("UPDATE loans SET status='Rejected' WHERE id=%s",(loan_id,))
    db.commit()

    return redirect("/manage_loans")
if __name__ == "__main__":
    app.run(debug=True)